Files in this folder represent SQL snippets used by sqlmap on the target
system.
They are licensed under the terms of the GNU Lesser General Public License
where not specified otherwise.
